
@php error_reporting(0); @endphp
<div class="modal-content perfect-scrollbar-example">
  <div class="modal-header">
    <h1 class="modal-title fs-5" id="staticBackdropLabel">Information</h1>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
  </div>

  <div class="modal-body">

    <div id="displaydata">@include('agent.formadminmodal')
     
       
      </div>

  </div>
  
</div>
